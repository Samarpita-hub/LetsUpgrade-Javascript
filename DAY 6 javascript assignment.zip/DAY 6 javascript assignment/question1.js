let Students = [
    
  ];

  function display(superarray) {
    let tabledata = "";
  
    superarray.forEach(function (Student, index) {
      let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${Student.name}</td>
      <td>${Student.age}</td>
      <td>${Student.city}</td>
      <td>${Student.salary}</td>
      <td>
      <button onclick='deleteStudent(${index})'>delete</button>
      <button onclick='showModal(${index})'>update</button>
      </td>
      </tr>`;
  
      tabledata += currentrow;
    });
  
    document.getElementsByClassName("tdata")[0].innerHTML = tabledata;

  }
  
  display(Students);
  
  function addStudent(e) {
    e.preventDefault();
    let Student = {};
    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let city = document.getElementById("city").value;
    let salary = document.getElementById("salary").value;
    Student.name = name;
    Student.age = Number(age);
    Student.city = city;
    Student.salary = salary;
  
    Students.push(Student);
  
    display(Students);
  
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("city").value = "";
    document.getElementById("salary").value = "";
  }
  
  function searchByName() {
    let searchValue = document.getElementById("searchName").value;
  
    let newdata = Students.filter(function (Student) {
      return (
        Student.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }

  function searchByCity() {
    let searchValue = document.getElementById("searchCity").value;
  
    let newdata = Students.filter(function (Student) {
      return (
        Student.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1
      );
    });
  
    display(newdata);
  }


  
  function deleteStudent(index) {
    Students.splice(index, 1);
    display(Students);
  }
  
  let updateIndex;
  
  function copyStudent(index) {
    updateIndex = index;
    let Student = Students[index];
  
    document.getElementById("upname").value = Student.name;
    document.getElementById("upage").value = Student.age;
    document.getElementById("upcity").value = Student.city;
    document.getElementById("upsalary").value = Student.salary;
  }
  
  function updateStudent(e) {
    e.preventDefault();
    let Student = Students[updateIndex];
    console.log(Student);
    let name = document.getElementById("upname").value;
    let age = document.getElementById("upage").value;
    let city = document.getElementById("upcity").value;
    let salary = document.getElementById("upsalary").value;
    Student.name = name;
    Student.age = Number(age);
    Student.city = city;
    Student.salary = salary;
    console.log(Student);
  
    display(Students);
  
    // code for hiding from anywhere
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "none";
  }
  
  function showModal(index) {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "block";
  
    copyStudent(index);
  }
  
  function hideModal(event) {
    if (event.target.className == "modal") {
      let modal = document.getElementsByClassName("modal")[0];
      modal.style.display = "none";
    }
  }