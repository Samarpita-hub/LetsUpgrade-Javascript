function changeImage0() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80";
      
  
    ele.src = newUrl;
  }
  
  function changeImage1() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://images.unsplash.com/photo-1464982326199-86f32f81b211?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1000&q=80";
      
  
    ele.src = newUrl;
  }
  
  function changeImage2() {
    const ele = document.getElementById("image");
    console.log(ele.id);
    const newUrl =
      "https://images-na.ssl-images-amazon.com/images/I/71IeYNcBYdL._SX569_.jpg";
     

    ele.src = newUrl;
  }
  