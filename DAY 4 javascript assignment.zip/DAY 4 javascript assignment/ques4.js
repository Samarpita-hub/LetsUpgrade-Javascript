var staff= [
  {
    name: "Niki",
    age: 22,
    country: "USA",
    hobbies: "painting",
   },
   {
     name: "Sandy",
     age: 24,
     country: "UK",
     hobbies: "reading books",
   },
   {
     name: "sams",
     age: 32,
     country: "India",
     hobbies: "listiening to music",
   },
   {
    name: "sani",
    age: 34,
    country: "Nepal",
    hobbies: "cooking",
  },
 ];

// A     
var resultArray = [];
for(var i=0; i<staff.length; i++) {
  if(staff[i].age < 30) {
    resultArray.push(staff[i]);
  }
}

console.log(resultArray);

// B
var resultArray = [];
for(var i=0; i<staff.length; i++) {
  if(staff[i].country == "India") {
    resultArray.push(staff[i]);
  }
}

console.log(resultArray);