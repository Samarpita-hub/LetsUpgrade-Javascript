let people = [
  {
    name: "Niki",
    age: 22,
    country: "USA",
    hobbies: "painting",
   },
   {
     name: "Sandy",
     age: 24,
     country: "UK",
     hobbies: "reading books",
   },
   {
     name: "sams",
     age: 32,
     country: "India",
     hobbies: "listiening to music",
   },
   {
    name: "sani",
    age: 34,
    country: "Nepal",
    hobbies: "cooking",
  },
 ];

 people.forEach(function (people) {
    console.log(people.name);
    console.log(people.age);
    console.log(people.country);
    console.log(people.hobbies);
   });

