function Fillauto(f) {
  if(f.filltoo.checked == true) {
    f.copyname.value = f.originalname.value;
  }
}
